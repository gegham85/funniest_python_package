from .text import joke as text_joke

def joke():
    return ('something here')
